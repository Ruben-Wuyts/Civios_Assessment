﻿using Assessment.Core.Enums;
using Assessment.Core.Interfaces;
using Assessment.Core.Results;

namespace Assessment.Core.Components
{
    public class Classifier : IDocumentClassifier
    {
        public DataClassificationResult AsignClassification(string text)
        {
            DataClassification dataClassification = new DataClassification();
            KeywordDictionary keywords = new KeywordDictionary();
            keywords = KeywordDictionary.CreateDictionary();
            
        }
    }
}
