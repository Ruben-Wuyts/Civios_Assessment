﻿using Assessment.Core.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment.Core.Components
{
    public class KeywordDictionary: Dictionary<DataClassification, List<string>>
    {
        public static KeywordDictionary CreateDictionary()
        {
            KeywordDictionary outgoingDictionary = new KeywordDictionary
            {
                { 0, new List<string>() { "brochure", "openbaar", "folder" } },
                { (DataClassification)1, new List<string>() { "memo", "vergadering", "nota" } },
                { (DataClassification)2, new List<string>() { "naam", "adres", "e-mailadres", "rijksregisternummer" } },
                { (DataClassification)3, new List<string>() { "medische", "financiële", "strafrechtelijke" } }
            };

            return outgoingDictionary;
        }
    }
}
