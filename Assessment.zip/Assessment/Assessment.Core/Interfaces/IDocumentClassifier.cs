﻿using Assessment.Core.Results;

namespace Assessment.Core.Interfaces
{
    internal interface IDocumentClassifier
    {
        public DataClassificationResult AsignClassification(string text);
    }
}
